﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Football;

namespace OPG4SimpleRESTService.Managers
{
    public class ManageFootballPlayers : IManageFootballPlayers
    {
        private static List<FootballPlayer> _footballPlayers = new List<FootballPlayer>()
        {
            new FootballPlayer(1, "Lukas", 10000, 8),
            new FootballPlayer(2, "Kevin", 12000, 9),
            new FootballPlayer(3, "Mark", 11000, 10),
            new FootballPlayer(4, "Jacob", 14000, 11),
            new FootballPlayer(5, "Benjamin", 9500, 12),
            new FootballPlayer(6, "Morten", 14500, 13),
            new FootballPlayer(7, "Adam", 13500, 14),
            new FootballPlayer(8, "Daniel", 11500, 15)
        };

        public IEnumerable<FootballPlayer> Get()
        {
            return new List<FootballPlayer>(_footballPlayers);
        }

        public FootballPlayer Get(int id)
        {
            return _footballPlayers.Find(f => f.Id == id);
        }

        public bool Create(FootballPlayer value)
        {
            _footballPlayers.Add(value);
            return true;
        }

        public bool Update(int id, FootballPlayer value)
        {
            FootballPlayer footballPlayer = Get(id);
            if (footballPlayer != null)
            {
                footballPlayer.Id = value.Id;
                footballPlayer.Name = value.Name;
                footballPlayer.Price = value.Price;
                footballPlayer.ShirtNumber = value.ShirtNumber;

                return true;
            }

            return false;
        }

        public FootballPlayer Delete(int id)
        {
            FootballPlayer footballPlayer = Get(id);
            _footballPlayers.Remove(footballPlayer);
            return footballPlayer;
        }
    }
}
